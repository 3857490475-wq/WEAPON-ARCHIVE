<?php
/**
 * Revel 武器档案库 - 排行 API
 * 功能：武器查询次数排行、武器伤害排行
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$dbPath = __DIR__ . '/a/rank.db';
$weaponsDir = __DIR__ . '/a';

// 初始化数据库
function initDB($dbPath) {
    $db = new SQLite3($dbPath);
    
    // 武器查询次数表
    $db->exec('
        CREATE TABLE IF NOT EXISTS weapon_views (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            weapon_id TEXT NOT NULL UNIQUE,
            weapon_name TEXT NOT NULL,
            weapon_type TEXT,
            weapon_rarity TEXT,
            view_count INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ');
    
    $db->exec('CREATE INDEX IF NOT EXISTS idx_views ON weapon_views(view_count DESC)');
    
    return $db;
}

// 扫描所有武器文件并初始化数据
function initWeaponData($db, $weaponsDir) {
    $indexFile = $weaponsDir . '/index.json';
    if (!file_exists($indexFile)) return;
    
    $index = json_decode(file_get_contents($indexFile), true);
    if (!$index || !isset($index['weapons'])) return;
    
    $stmt = $db->prepare('
        INSERT OR IGNORE INTO weapon_views (weapon_id, weapon_name, weapon_type, weapon_rarity, view_count)
        VALUES (:id, :name, :type, :rarity, 0)
    ');
    
    foreach ($index['weapons'] as $weapon) {
        $weaponFile = $weaponsDir . '/' . ltrim($weapon['file'], 'a/');
        if (file_exists($weaponFile)) {
            $weaponData = json_decode(file_get_contents($weaponFile), true);
            if ($weaponData) {
                $stmt->bindValue(':id', $weaponData['id'], SQLITE3_TEXT);
                $stmt->bindValue(':name', $weaponData['name'], SQLITE3_TEXT);
                $stmt->bindValue(':type', $weaponData['type'], SQLITE3_TEXT);
                $stmt->bindValue(':rarity', $weaponData['rarity'], SQLITE3_TEXT);
                $stmt->execute();
                $stmt->reset();
            }
        }
    }
}

// 获取武器查询次数排行
function getViewRankings($db, $limit = 50) {
    $stmt = $db->prepare("
        SELECT weapon_id, weapon_name, weapon_type, weapon_rarity, view_count, updated_at
        FROM weapon_views 
        ORDER BY view_count DESC 
        LIMIT :limit
    ");
    $stmt->bindValue(':limit', $limit, SQLITE3_INTEGER);
    
    $result = $stmt->execute();
    $rankings = [];
    
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $rankings[] = $row;
    }
    
    return $rankings;
}

// 获取武器伤害排行
function getDamageRankings($weaponsDir, $limit = 50) {
    $indexFile = $weaponsDir . '/index.json';
    if (!file_exists($indexFile)) return [];
    
    $index = json_decode(file_get_contents($indexFile), true);
    if (!$index || !isset($index['weapons'])) return [];
    
    $weapons = [];
    
    foreach ($index['weapons'] as $weapon) {
        $weaponFile = $weaponsDir . '/' . ltrim($weapon['file'], 'a/');
        if (file_exists($weaponFile)) {
            $weaponData = json_decode(file_get_contents($weaponFile), true);
            if ($weaponData && isset($weaponData['stats'])) {
                // 提取伤害值（精神破坏力）
                $damage = 0;
                if (isset($weaponData['stats']['精神破坏力'])) {
                    $damage = intval($weaponData['stats']['精神破坏力']);
                }
                
                $weapons[] = [
                    'weapon_id' => $weaponData['id'],
                    'weapon_name' => $weaponData['name'],
                    'weapon_type' => $weaponData['type'],
                    'weapon_rarity' => $weaponData['rarity'],
                    'damage' => $damage,
                    'typeName' => $weaponData['typeName'] ?? '',
                    'rarityName' => $weaponData['rarityName'] ?? ''
                ];
            }
        }
    }
    
    // 按伤害排序
    usort($weapons, function($a, $b) {
        return $b['damage'] - $a['damage'];
    });
    
    return array_slice($weapons, 0, $limit);
}

// 记录查询次数
function recordView($db, $weaponId) {
    $stmt = $db->prepare("
        UPDATE weapon_views 
        SET view_count = view_count + 1, updated_at = datetime('now')
        WHERE weapon_id = :id
    ");
    $stmt->bindValue(':id', $weaponId, SQLITE3_TEXT);
    $stmt->execute();
}

// 主逻辑
try {
    $db = initDB($dbPath);
    initWeaponData($db, $weaponsDir);
    
    $action = isset($_GET['action']) ? $_GET['action'] : 'list';
    
    switch ($action) {
        case 'view':
            // 记录查询
            $weaponId = isset($_GET['id']) ? $_GET['id'] : '';
            if ($weaponId) {
                recordView($db, $weaponId);
                echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode(['error' => '缺少武器ID'], JSON_UNESCAPED_UNICODE);
            }
            break;
            
        case 'rank':
            // 获取排行
            $type = isset($_GET['type']) ? $_GET['type'] : 'views';
            $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
            
            if ($type === 'damage') {
                $rankings = getDamageRankings($weaponsDir, $limit);
                echo json_encode([
                    'type' => 'damage',
                    'rankings' => $rankings,
                    'total' => count($rankings)
                ], JSON_UNESCAPED_UNICODE);
            } else {
                $rankings = getViewRankings($db, $limit);
                echo json_encode([
                    'type' => 'views',
                    'rankings' => $rankings,
                    'total' => count($rankings)
                ], JSON_UNESCAPED_UNICODE);
            }
            break;
            
        default:
            echo json_encode(['error' => '未知操作'], JSON_UNESCAPED_UNICODE);
    }
    
    $db->close();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => '服务器错误',
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
